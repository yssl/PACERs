#include <stdio.h>
int main()
{
    printf("Hello world 2\n");
    return 0;
}
