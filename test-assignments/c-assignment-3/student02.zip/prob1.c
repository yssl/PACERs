#include <stdio.h>
int main()
{
    aprintf("Hello world\n");
    return 0;
}
