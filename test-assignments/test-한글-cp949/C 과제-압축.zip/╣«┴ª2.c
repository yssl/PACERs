#include <stdio.h>
int main()
{
    int a, b;
    printf("����2\n");
    return 0;
}