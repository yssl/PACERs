#include <stdio.h>
int main()
{
    printf("문제1\n");
    return 0;
}
