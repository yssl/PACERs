#include <stdio.h>
int main()
{
    int a, b;
    printf("문제2\n");
    return 0;
}
