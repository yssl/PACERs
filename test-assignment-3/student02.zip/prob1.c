#include <stdio.h>
int main()
{
    printf("Hello world\n");
    aprintf("�ѱ�\n");
    return 0;
}