#include <stdio.h>
int main()
{
    printf("Hello world\n");
    printf("�ѱ�\n");
    return 0;
}